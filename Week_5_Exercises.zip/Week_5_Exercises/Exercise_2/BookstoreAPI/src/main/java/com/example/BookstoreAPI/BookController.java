package com.example.BookstoreAPI;

import com.example.BookstoreAPI.BookDTO;
import com.example.BookstoreAPI.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<BookDTO>> getBookById(@PathVariable Long id) {
        BookDTO bookDTO = bookService.getBookById(id);

        EntityModel<BookDTO> resource = EntityModel.of(bookDTO);
        resource.add(linkTo(methodOn(BookController.class).getBookById(id)).withSelfRel());
        resource.add(linkTo(methodOn(BookController.class).getAllBooks()).withRel("all-books"));

        return ResponseEntity.ok(resource);
    }

    @GetMapping
    public List<EntityModel<BookDTO>> getAllBooks() {
        return bookService.getAllBooks().stream()
                .map(bookDTO -> {
                    EntityModel<BookDTO> resource = EntityModel.of(bookDTO);
                    resource.add(linkTo(methodOn(BookController.class).getBookById(bookDTO.getId())).withSelfRel());
                    return resource;
                })
                .collect(Collectors.toList());
    }

    @GetMapping("/paginated")
    public Page<EntityModel<BookDTO>> getAllBooksPaginated(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy) {

        Page<BookDTO> bookDTOPage = bookService.getAllBooksPaginated(page, size, sortBy);

        return bookDTOPage.map(bookDTO -> {
            EntityModel<BookDTO> resource = EntityModel.of(bookDTO);
            resource.add(linkTo(methodOn(BookController.class).getBookById(bookDTO.getId())).withSelfRel());
            return resource;
        });
    }

}
