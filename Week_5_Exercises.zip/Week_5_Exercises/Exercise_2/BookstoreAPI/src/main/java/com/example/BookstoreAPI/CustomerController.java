package com.example.BookstoreAPI;

import com.example.BookstoreAPI.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<CustomerDTO>> getCustomerById(@PathVariable Long id) {
        CustomerDTO customerDTO = customerService.getCustomerById(id);

        EntityModel<CustomerDTO> resource = EntityModel.of(customerDTO);
        resource.add(linkTo(methodOn(CustomerController.class).getCustomerById(id)).withSelfRel());
        resource.add(linkTo(methodOn(CustomerController.class).getAllCustomers()).withRel("all-customers"));

        return ResponseEntity.ok(resource);
    }

    @GetMapping
    public List<EntityModel<CustomerDTO>> getAllCustomers() {
        return customerService.getAllCustomers().stream()
                .map(customerDTO -> {
                    EntityModel<CustomerDTO> resource = EntityModel.of(customerDTO);
                    resource.add(linkTo(methodOn(CustomerController.class).getCustomerById(customerDTO.getId()))
                            .withSelfRel());
                    return resource;
                })
                .collect(Collectors.toList());
    }

}
