package com.example.BookstoreAPI;

import com.example.BookstoreAPI.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
