package main.java.com.example.BookstoreAPI;

import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MetricsController {

    private final MeterRegistry meterRegistry;
    private int visitCount = 0;

    public MetricsController(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @GetMapping("/visit")
    public String visit() {
        visitCount++;
        meterRegistry.counter("visit_count").increment();
        return "Visit count: " + visitCount;
    }
}
