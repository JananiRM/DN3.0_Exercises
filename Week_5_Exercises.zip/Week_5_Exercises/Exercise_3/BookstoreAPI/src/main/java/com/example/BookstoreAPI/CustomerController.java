package com.example.BookstoreAPI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping(value = "/{id}", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<EntityModel<CustomerDTO>> getCustomerById(@PathVariable Long id, 
                                                                    @RequestHeader(value = "Accept", defaultValue = MediaType.APPLICATION_JSON_VALUE) String acceptHeader) {
        CustomerDTO customerDTO = customerService.getCustomerById(id);
        EntityModel<CustomerDTO> resource = EntityModel.of(customerDTO);
        resource.add(linkTo(methodOn(CustomerController.class).getCustomerById(id, acceptHeader)).withSelfRel());
        resource.add(linkTo(methodOn(CustomerController.class).getAllCustomers(acceptHeader)).withRel("all-customers"));

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(acceptHeader))
                .body(resource);
    }

    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<List<EntityModel<CustomerDTO>>> getAllCustomers(@RequestHeader(value = "Accept", defaultValue = MediaType.APPLICATION_JSON_VALUE) String acceptHeader) {
        List<EntityModel<CustomerDTO>> customers = customerService.getAllCustomers().stream()
                .map(customerDTO -> {
                    EntityModel<CustomerDTO> resource = EntityModel.of(customerDTO);
                    resource.add(linkTo(methodOn(CustomerController.class).getCustomerById(customerDTO.getId(), acceptHeader)).withSelfRel());
                    return resource;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(acceptHeader))
                .body(customers);
    }

    @PostMapping(consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, 
                 produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<EntityModel<CustomerDTO>> createCustomer(@RequestBody CustomerDTO customerDTO, 
                                                                  @RequestHeader(value = "Accept", defaultValue = MediaType.APPLICATION_JSON_VALUE) String acceptHeader) {
        CustomerDTO createdCustomer = customerService.createCustomer(customerDTO);
        EntityModel<CustomerDTO> resource = EntityModel.of(createdCustomer);
        return ResponseEntity.status(HttpStatus.CREATED)
                .contentType(MediaType.parseMediaType(acceptHeader))
                .body(resource);
    }

    @PutMapping(value = "/{id}", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, 
                produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<EntityModel<CustomerDTO>> updateCustomer(@PathVariable Long id, @RequestBody CustomerDTO customerDTO, 
                                                                  @RequestHeader(value = "Accept", defaultValue = MediaType.APPLICATION_JSON_VALUE) String acceptHeader) {
        CustomerDTO updatedCustomer = customerService.updateCustomer(id, customerDTO);
        EntityModel<CustomerDTO> resource = EntityModel.of(updatedCustomer);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(acceptHeader))
                .body(resource);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        customerService.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }
}
