package com.example.BookstoreAPI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping(value = "/{id}", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<EntityModel<BookDTO>> getBookById(@PathVariable Long id, 
                                                             @RequestHeader(value = "Accept", defaultValue = MediaType.APPLICATION_JSON_VALUE) String acceptHeader) {
        BookDTO bookDTO = bookService.getBookById(id);
        EntityModel<BookDTO> resource = EntityModel.of(bookDTO);
        // Add HATEOAS links if using Spring HATEOAS
        resource.add(linkTo(methodOn(BookController.class).getBookById(id, acceptHeader)).withSelfRel());
        resource.add(linkTo(methodOn(BookController.class).getAllBooks(acceptHeader)).withRel("all-books"));

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(acceptHeader))
                .body(resource);
    }

    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<List<EntityModel<BookDTO>>> getAllBooks(@RequestHeader(value = "Accept", defaultValue = MediaType.APPLICATION_JSON_VALUE) String acceptHeader) {
        List<EntityModel<BookDTO>> books = bookService.getAllBooks().stream()
                .map(bookDTO -> {
                    EntityModel<BookDTO> resource = EntityModel.of(bookDTO);
                    resource.add(linkTo(methodOn(BookController.class).getBookById(bookDTO.getId(), acceptHeader)).withSelfRel());
                    return resource;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(acceptHeader))
                .body(books);
    }

    @PostMapping(consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, 
                 produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<EntityModel<BookDTO>> createBook(@RequestBody BookDTO bookDTO, 
                                                            @RequestHeader(value = "Accept", defaultValue = MediaType.APPLICATION_JSON_VALUE) String acceptHeader) {
        BookDTO createdBook = bookService.createBook(bookDTO);
        EntityModel<BookDTO> resource = EntityModel.of(createdBook);
        return ResponseEntity.status(HttpStatus.CREATED)
                .contentType(MediaType.parseMediaType(acceptHeader))
                .body(resource);
    }

    @PutMapping(value = "/{id}", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, 
                produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<EntityModel<BookDTO>> updateBook(@PathVariable Long id, @RequestBody BookDTO bookDTO, 
                                                            @RequestHeader(value = "Accept", defaultValue = MediaType.APPLICATION_JSON_VALUE) String acceptHeader) {
        BookDTO updatedBook = bookService.updateBook(id, bookDTO);
        EntityModel<BookDTO> resource = EntityModel.of(updatedBook);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(acceptHeader))
                .body(resource);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        bookService.deleteBook(id);
        return ResponseEntity.noContent().build();
    }
}
