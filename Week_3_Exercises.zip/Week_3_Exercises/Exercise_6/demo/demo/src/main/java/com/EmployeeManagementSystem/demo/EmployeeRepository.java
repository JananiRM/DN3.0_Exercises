package com.EmployeeManagementSystem.demo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    Page<Employee> findByDepartmentName(String departmentName, Pageable pageable);

    List<Employee> findAllByOrderByEmail(Sort sort);
}
