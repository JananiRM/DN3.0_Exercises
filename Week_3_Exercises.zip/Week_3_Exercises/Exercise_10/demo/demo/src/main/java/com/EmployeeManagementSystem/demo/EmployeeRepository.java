package com.EmployeeManagementSystem.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Query("SELECT e FROM Employee e")
    Page<EmployeeProjection> findEmployeeProjections(Pageable pageable);

    Page<Employee> findByDepartmentName(String departmentName, Pageable pageable);
    List<Employee> findAllByOrderByEmail(Sort sort);
}
