package com.EmployeeManagementSystem.demo;

import org.springframework.beans.factory.annotation.Value;

public class DepartmentProjection {

    private final Long id;
    private final String name;
    private final int employeeCount;

    public DepartmentProjection(Long id, String name, int employeeCount) {
        this.id = id;
        this.name = name;
        this.employeeCount = employeeCount;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getEmployeeCount() {
        return employeeCount;
    }
}
