package main.java.com.EmployeeManagementSystem.demo;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "Employee")
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    @ManyToOne
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;
}
